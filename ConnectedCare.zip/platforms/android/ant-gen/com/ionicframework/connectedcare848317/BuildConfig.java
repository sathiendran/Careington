/** Automatically generated file. DO NOT MODIFY */
package com.ionicframework.connectedcare848317;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}
module.exports = {
    colors: require('./colors'),
    condense: require('./condense'),
    indent: require('./indent'),
    rpad: require('./rpad'),
    sum: require('./sum')
};

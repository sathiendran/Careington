describe('integration tests', function () {
    require('./init');
    require('./install');
    require('./uninstall');
    require('./update');
});
